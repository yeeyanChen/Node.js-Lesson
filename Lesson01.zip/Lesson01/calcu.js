function add1(num1, num2) {
  console.log(num1 + num2 + 100);
}

module.exports = {
  add1,
};
